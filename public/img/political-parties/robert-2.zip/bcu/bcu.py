# Integrantes
# Roberto Armas
# Eduardo Loza

# Algoritmo de busqueda de costo uniforme

from graph import *
from priority_queue import PriorityQueue

def UniformCostSearch(Graph, root, goal):
    if root not in graph.getNodes() or goal not in graph.getNodes():
        print('Error: root \'%s\' or goal \'%s\' not exists!!' % (root, goal))
    else:
        queue = PriorityQueue()
        keys_successors = graph.getSuccessors(root)

        for key_sucessor in keys_successors:
            weight = graph.getWeightEdge(root, key_sucessor)
            queue.insert((key_sucessor, weight, [root]), weight)
            print queue._queue

        print "-----------------"

        reached_goal, cumulative_cost_goal = False, -1

        while not queue.is_empty():
            key_current_node, cost_node, path = queue.remove()

            if(key_current_node == goal):
                reached_goal, cumulative_cost_goal = True, cost_node
                break


            keys_successors = graph.getSuccessors(key_current_node)

            if keys_successors: # checks if contains successors
                # insert all successors of key_current_node in the queue
                for key_sucessor in keys_successors:
                    cumulative_cost = graph.getWeightEdge(key_current_node, key_sucessor) + cost_node
                    tmp = path[:]
                    tmp.append(key_current_node)
                    print tmp
                    queue.insert((key_sucessor, cumulative_cost, tmp), cumulative_cost)
                    print queue._queue

        if(reached_goal):
            print('\nCosto: %s\n' % cumulative_cost_goal)
            print printPath(path) + goal
        else:
            print('\nNo hay objetivo.\n')

def printPath(path):
    pathString = ""
    for p in path:
        pathString += p + "->"
    return pathString




if __name__ == "__main__":

    graph = Graph()
    graph.addNode('S') # start
    graph.addNode('A')
    graph.addNode('B')
    graph.addNode('C')
    graph.addNode('D')
    graph.addNode('G')

    # # linking the nodes
    graph.connect('S', 'A', 1)
    graph.connect('S', 'G', 12)
    graph.connect('A', 'B', 3)
    graph.connect('A', 'C', 1)
    graph.connect('B', 'D', 3)
    graph.connect('C', 'D', 1)
    graph.connect('D', 'G', 3)
    graph.connect('C', 'G', 2)


    UniformCostSearch(graph,'S','G')
